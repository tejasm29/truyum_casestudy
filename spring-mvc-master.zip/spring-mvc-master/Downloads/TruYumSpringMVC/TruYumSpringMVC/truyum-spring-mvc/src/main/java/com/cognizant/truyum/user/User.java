package com.cognizant.truyum.user;

public class User {
	private String userName;
	private int userId;
	private long userPhone;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int userId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public long getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}
}
